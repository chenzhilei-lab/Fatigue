"""
plot_results.py — Publication-quality figures for gear fatigue UQ paper
========================================================================
Figure 1: Fatigue life distribution by size/surface standard (violin + box)
Figure 2: Variance decomposition bar chart with bootstrap error bars
Figure 3: Interaction: Rz × standard → median log10(Nf)
"""

import json, os
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch

os.chdir(os.path.dirname(os.path.abspath(__file__)))
os.makedirs('output', exist_ok=True)

# Load data
with open('output/sweep.json') as f:
    sweep = json.load(f)
with open('output/anova.json') as f:
    anova = json.load(f)

valid = [r for r in sweep if r['log10_Nf'] is not None]
logNf = np.array([r['log10_Nf'] for r in valid])

# ===============================================================
# STYLE SETUP
# ===============================================================
plt.rcParams.update({
    'font.size': 11,
    'axes.titlesize': 13,
    'axes.labelsize': 12,
    'legend.fontsize': 9,
    'figure.dpi': 150,
    'savefig.dpi': 300,
    'savefig.bbox': 'tight',
})

COLORS = {
    'ISO_6336': '#2166ac',
    'AGMA_2001': '#b2182b',
    'FKM': '#4daf4a',
    'ground_Rz4': '#fde0dd',
    'machined_Rz15': '#f4a582',
    'as_forged_Rz50': '#ca0020',
}
STANDARD_ORDER = ['ISO_6336', 'AGMA_2001', 'FKM']
RZ_ORDER = ['ground_Rz4', 'machined_Rz15', 'as_forged_Rz50']
RZ_LABELS = {'ground_Rz4': 'Ground\n(Rz=4μm)',
             'machined_Rz15': 'Machined\n(Rz=15μm)',
             'as_forged_Rz50': 'As-forged\n(Rz=50μm)'}

# ===============================================================
# FIGURE 1: Fatigue life distribution by standard
# ===============================================================
fig1, (ax1a, ax1b) = plt.subplots(1, 2, figsize=(9, 5), gridspec_kw={'width_ratios': [2, 1]})

# 1a: Violin + box plot
data_by_std = []
positions = [1, 2, 3]
for std in STANDARD_ORDER:
    vals = [r['log10_Nf'] for r in valid if r['size_surface_standard'] == std]
    data_by_std.append(vals)

vp = ax1a.violinplot(data_by_std, positions=positions, widths=0.7,
                      showmeans=False, showmedians=True)
bp = ax1a.boxplot(data_by_std, positions=positions, widths=0.15,
                   patch_artist=True, medianprops={'color': 'black', 'linewidth': 1.5},
                   showfliers=False)

for i, std in enumerate(STANDARD_ORDER):
    bp['boxes'][i].set_facecolor(COLORS[std])
    bp['boxes'][i].set_alpha(0.6)
    for body in vp['bodies']:
        body.set_alpha(0.15)
ax1a.set_xticks(positions)
ax1a.set_xticklabels(STANDARD_ORDER, fontsize=10)
ax1a.set_ylabel(r'$\log_{10}(N_f)$', fontsize=12)
ax1a.set_title('Fatigue life spread by size/surface standard', fontsize=12)
ax1a.grid(axis='y', alpha=0.3, linestyle='--')

# Add Nf labels on right axis
def log_to_Nf_str(logv):
    if logv >= 6: return f'$10^{{{int(logv)}}}$'
    elif logv <= 2: return f'$10^{{{logv:.1f}}}$'
    else: return f'$10^{{{logv:.0f}}}$'

ax1a.text(0.02, 0.98, f'$N_f$: 13 to $1.3\\times10^6$ cycles\n5 dex spread',
          transform=ax1a.transAxes, va='top', fontsize=9, style='italic',
          bbox=dict(boxstyle='round,pad=0.3', facecolor='wheat', alpha=0.8))

# 1b: Bars showing run-out vs finite-life counts
runout_counts = []
finite_counts = []
for std in STANDARD_ORDER:
    n_runout = sum(1 for r in sweep if r['size_surface_standard'] == std and r['log10_Nf'] is None)
    n_finite = sum(1 for r in sweep if r['size_surface_standard'] == std and r['log10_Nf'] is not None)
    runout_counts.append(n_runout)
    finite_counts.append(n_finite)

x = np.arange(3)
w = 0.35
bars_finite = ax1b.bar(x - w/2, finite_counts, w, label='Finite life',
                        color=['#2166ac', '#b2182b', '#4daf4a'], alpha=0.8)
bars_runout = ax1b.bar(x + w/2, runout_counts, w, label='Run-out ($>10^7$)',
                        color=['lightsteelblue', 'lightcoral', 'lightgreen'], alpha=0.8)
ax1b.set_xticks(x)
ax1b.set_xticklabels(STANDARD_ORDER, fontsize=10)
ax1b.set_ylabel('Number of combinations', fontsize=12)
ax1b.set_title('Run-out vs finite-life by standard', fontsize=12)
ax1b.legend(fontsize=8, loc='upper right')
ax1b.grid(axis='y', alpha=0.3, linestyle='--')

# Annotate percentages
for i, (r, f) in enumerate(zip(runout_counts, finite_counts)):
    total = r + f
    ax1b.text(i - w/2, f + 3, f'{100*f/total:.0f}%', ha='center', fontsize=8)
    if r > 0:
        ax1b.text(i + w/2, r + 3, f'{100*r/total:.0f}%', ha='center', fontsize=8)

plt.tight_layout()
fig1.savefig('output/fig1_life_spread_by_standard.png')
plt.close()
print('Saved fig1_life_spread_by_standard.png')

# ===============================================================
# FIGURE 2: Variance decomposition bar chart
# ===============================================================
fig2, ax2 = plt.subplots(figsize=(8, 5))

factors_display = [
    ('Size/surface\nstandard', 'size_surface_standard'),
    ('Mean stress\ncorrection', 'mean_stress_method'),
    ('Surface roughness\n(Rz)', 'rz_level'),
    ('S–N curve\nsource', 'sn_source'),
    ('Std × Rz\ninteraction', 'size_surface_standard × rz_level'),
    ('Cumulative\ndamage rule', 'damage_method'),
]

var_means = []
var_lowers = []
var_uppers = []
for _, fkey in factors_display:
    nf = anova['bootstrap']['noise_floor'][fkey]
    var_means.append(nf['mean'])
    var_lowers.append(nf['mean'] - nf['ci_95_lower'])
    var_uppers.append(nf['ci_95_upper'] - nf['mean'])

labels = [l for l, _ in factors_display]
colors_bar = ['#2166ac', '#2166ac', '#2166ac', '#999999', '#999999', '#999999']

# Horizontal bars
ypos = range(len(labels))[::-1]
bars = ax2.barh(ypos, var_means, xerr=[var_lowers, var_uppers],
                color=colors_bar, alpha=0.85, capsize=3, height=0.6)

ax2.set_yticks(ypos)
ax2.set_yticklabels(labels, fontsize=10)
ax2.set_xlabel('Variance fraction (%)', fontsize=12)
ax2.set_title('What drives gear fatigue life divergence?', fontsize=13, fontweight='bold')

# Annotate percentages
for i, (mean, lower, upper) in enumerate(zip(var_means, var_lowers, var_uppers)):
    ax2.text(mean + 2, ypos[i],
             f'{mean:.1f}%  [{mean-lower:.1f}–{mean+upper:.1f}]',
             va='center', fontsize=8.5)

# Legend
legend_elements = [
    Patch(facecolor='#2166ac', alpha=0.85, label='Dominant factors (78% combined)'),
    Patch(facecolor='#999999', alpha=0.85, label='Negligible (<2% combined)'),
]
ax2.legend(handles=legend_elements, loc='lower right', fontsize=8.5)

ax2.grid(axis='x', alpha=0.3, linestyle='--')
ax2.set_xlim(0, max(var_means) * 1.25)

plt.tight_layout()
fig2.savefig('output/fig2_variance_decomposition.png')
plt.close()
print('Saved fig2_variance_decomposition.png')

# ===============================================================
# FIGURE 3: Interaction plot — Rz × standard
# ===============================================================
fig3, ax3 = plt.subplots(figsize=(7, 5))

for i, std in enumerate(STANDARD_ORDER):
    medians = []
    q25s = []
    q75s = []
    for rz in RZ_ORDER:
        vals = [r['log10_Nf'] for r in valid
                if r['size_surface_standard'] == std and r['rz_level'] == rz]
        if vals:
            v = np.array(vals)
            medians.append(np.median(v))
            q25s.append(np.percentile(v, 25))
            q75s.append(np.percentile(v, 75))
        else:
            medians.append(np.nan); q25s.append(np.nan); q75s.append(np.nan)

    x = np.arange(3)
    line = ax3.plot(x, medians, 'o-', color=COLORS[std], linewidth=2,
                    markersize=8, label=std, alpha=0.9)
    ax3.fill_between(x, q25s, q75s, color=COLORS[std], alpha=0.12)

ax3.set_xticks([0, 1, 2])
ax3.set_xticklabels([RZ_LABELS[rz] for rz in RZ_ORDER], fontsize=10)
ax3.set_ylabel(r'Median $\log_{10}(N_f)$', fontsize=12)
ax3.set_title('Interaction: surface roughness × standard', fontsize=12)
ax3.legend(fontsize=9, loc='best')
ax3.grid(alpha=0.3, linestyle='--')

# Annotate the spread for as-forged condition
ax3.annotate('ISO vs AGMA:\n~2 dex gap\nat rough surface',
             xy=(2, medians[0]), xytext=(2.3, medians[0] + 0.8),
             arrowprops=dict(arrowstyle='->', color='#2166ac'),
             fontsize=8, color='#2166ac')

plt.tight_layout()
fig3.savefig('output/fig3_rz_standard_interaction.png')
plt.close()
print('Saved fig3_rz_standard_interaction.png')

# ===============================================================
# SUMMARY
# ===============================================================
print(f"""
Figures generated in output/:
  fig1_life_spread_by_standard.png  — Nf distributions + run-out counts
  fig2_variance_decomposition.png   — ANOVA bar chart with bootstrap CI
  fig3_rz_standard_interaction.png  — Rz × standard interaction

Paper ready for:
  pdflatex paper/gear_fatigue_v2.8.tex
""")
