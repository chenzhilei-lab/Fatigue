#!/bin/bash
# ================================================================
# Gear Fatigue UQ — One-Click Reproducibility
# Usage: bash reproduce.sh
# Requirements: Python 3.10+, numpy, scipy, matplotlib
# ================================================================
set -e
cd "$(dirname "$0")"

echo "=== [1/5] Full-factorial sweep (144 combinations) ==="
python run_sweep.py

echo ""
echo "=== [2/5] Variance decomposition (ANOVA + bootstrap) ==="
python variance_decomposition.py

echo ""
echo "=== [3/5] Multi-torque comparison ==="
python multi_torque_analysis.py

echo ""
echo "=== [4/5] Figures ==="
python plot_results.py

echo ""
echo "=== [5/5] Paper audit ==="
python paper_check.py paper/gear_fatigue_v2.8.tex

echo ""
echo "=========================================="
echo " DONE. All outputs in output/"
echo "=========================================="
