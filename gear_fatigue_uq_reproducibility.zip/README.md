# Gear Fatigue UQ — Reproducibility Package

**Paper:** Method-Induced Uncertainty in Gear Bending Fatigue: Factorial Variance Decomposition Across Five Engineering Choices  
**Author:** Zhilei Chen (Guangdong Peizheng College)  
**Submitted to:** *International Journal of Fatigue* (Elsevier)

## Quick Start

```bash
bash reproduce.sh
```

Runs 5 steps: sweep → ANOVA → multi-torque → figures → audit. ~10 seconds.

## Requirements

- Python 3.10+
- numpy, scipy, matplotlib

## File Tree

```
├── reproduce.sh              # One-click reproduction
├── README.md
├── run_sweep.py              # 144-combination full-factorial sweep
├── variance_decomposition.py # ANOVA + bootstrap (2000 draws)
├── multi_torque_analysis.py  # Torque dependence: 500/600/700 Nm
├── plot_results.py           # Publication figures
├── paper_check.py            # Universal paper auditor
├── fatigue_models.py         # ISO 6336 / AGMA / FKM implementations
├── gear_params.py            # Fixed gear geometry + material
├── generate_labels_v2.py     # Label generator for audit
├── paper/
│   ├── gear_fatigue_v2.8.tex # LaTeX source
│   └── gear_fatigue_v2.8.pdf # Compiled PDF
└── output/
    ├── sweep.json            # Raw 144 results
    ├── sweep_summary.json    # Summary stats
    ├── anova.json            # ANOVA + bootstrap
    ├── multi_torque_anova.json # Torque-dependent results
    └── labels.json           # 78 labeled values
```

## Methodology

| Switch | Options | Count |
|--------|---------|:-----:|
| S-N curve source | Waterloo #66, #68 | 2 |
| Mean stress correction | Goodman, Gerber, Morrow, SWT | 4 |
| Cumulative damage rule | Miner, Modified Miner | 2 |
| Size & surface standard | ISO 6336, AGMA 2001, FKM | 3 |
| Surface roughness Rz | 4, 15, 50 μm | 3 |

Fixed: module 3 mm, 20 teeth, 42CrMo4, 700 N·m, R=0

## Key Results

| Factor | Variance % | S/N |
|--------|:----------:|:---:|
| Size/surface standard | 31.1% | 5 |
| Mean stress correction | 30.9% | 5 |
| Surface roughness | 8.5% | 2 |
| Standard × Rz | 5.0% | 2 |
| S-N source | 0.7% | 1 |
| Damage rule | 0.5% | 1 |

Nf range: 3.3×10² – 3.1×10⁷ (5.0 dex)

## Formula Verification

All implementations verified against original standards: ISO 6336-3:2019, AGMA 2001-D04, FKM 7th ed. S-N parameters from publicly accessible Waterloo SMDIdbase.

## Audit

```bash
python paper_check.py paper/gear_fatigue_v2.8.tex
# → 66 numbers traced, 0 orphans, PASS
```
